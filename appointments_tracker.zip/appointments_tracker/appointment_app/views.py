from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import * 
import bcrypt

def index(request):
    return render(request, 'index.html')

def create_user(request):
    if request.method == "GET":
        return redirect('/')

    errors = User.objects.register_validator(request.POST)

    if len (errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else: 
        user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        )
    request.session['user_id'] = user.id
    request.session['first_name'] = user.first_name
    return redirect('/user/dashboard')

def login(request):    
    errors = User.objects.login_validator(request.POST)
    if len (errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    user = User.objects.filter(email=request.POST['email'])
    
    request.session['user_id'] = user[0].id
    return redirect('/user/dashboard')

def logout(request):
    request.session.clear()
    return redirect('/')

def dashboard(request): 
    logged_user = User.objects.get(id=request.session['user_id'])
    context = {
        'appointments': Appointment.objects.all(),
        'first_name' : logged_user.first_name,
        'user_id': logged_user.id,
        
    }
    return render(request,'dashboard.html', context)

def to_appt(request):
    return render(request, 'add_appointment.html')

def new_appointment(request):
    if 'user_id' not in request.session:
        messages.error(request, "Please register or log in first!")
        return redirect('/')
    errors = Appointment.objects.appt_validator(request.POST)
    if len (errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/appointment/to_appt')  
    else:
        this_appt = Appointment.objects.create(
            task = request.POST['task'],
            date = request.POST['date'],
            status = request.POST['status'],   
        )
    user = User.objects.get(id=request.session['user_id'])
    appointment = this_appt
    request.session['appointment_id'] = appointment.id
    return redirect('/user/dashboard')

def edit_appointment(request, appointment_id):
    context = {
        'appointment': Appointment.objects.get(id=appointment_id)
    }
    return render(request, 'edit_appointment.html', context)

def update_appointment(request, appointment_id):
    to_update = Appointment.objects.get(id=appointment_id)

    to_update.task = request.POST['task']
    to_update.date = request.POST['date']
    to_update.status = request.POST['status']

    errors = Appointment.objects.appt_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/appointment/{appointment_id}/edit_appointment')
    else:
        update_appointment = Appointment.objects.get(id = appointment_id)
        update_appointment.task = request.POST['task']
        update_appointment.date = request.POST['date']
        update_appointment.status = request.POST['status']
        update_appointment.save()
        messages.success(request, "Appointment Updated!")
        return redirect('/user/dashboard')

def updated_appt(request, appointment_id):
    logged_user = User.objects.get(id=request.session['user_id'])
    all_user_appointments = Appointment.objects.filter(user = logged_user.id)
    context = {
        'all_appointments': all_user_appointments
    }
    return render(request, 'dashboard.html')

def delete(request, appointment_id):
    appointment_to_delete = Appointment.objects.get(id=appointment_id)
    appointment_to_delete.delete()
    return redirect('/user/dashboard')