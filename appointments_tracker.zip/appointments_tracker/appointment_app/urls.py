from django.urls import path, include 
from . import views 

urlpatterns = [
    path('', views.index), # login/reg
    path('user/create_user', views.create_user), # create user
    path('user/dashboard', views.dashboard), #dashboard
    path('user/login', views.login), #login
    path('user/logout', views.logout), #logout
    path('appointment/to_appt', views.to_appt), # to new appt html 
    path('appointment/new_appointment', views.new_appointment), # new appointment create new 
    path('appointment/<int:appointment_id>/edit_appointment', views.edit_appointment), # to edit page
    path('appointment/<int:appointment_id>/update_appointment', views.update_appointment), # upate appointment
    path('appointment/<int:appointment_id>/updated_appt', views.updated_appt), # upate appointment
    path('appointment/<int:appointment_id>/delete', views.delete), # to delete appointment
]
