from django.urls import path, include

urlpatterns = [
    path('',include('appointment_app.urls')),
]
